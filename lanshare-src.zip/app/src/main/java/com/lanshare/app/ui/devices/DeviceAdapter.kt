package com.lanshare.app.ui.devices

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.lanshare.app.data.LanDevice
import com.lanshare.app.databinding.ItemDeviceBinding
import com.lanshare.app.net.ConnState
import com.lanshare.app.net.Hub

class DeviceAdapter(
    private val onClick: (LanDevice) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.VH>() {

    private val items = ArrayList<LanDevice>()

    fun submit(list: List<LanDevice>) {
        items.clear()
        items.addAll(list.sortedBy { it.name })
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemDeviceBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        holder.b.tvName.text = d.name
        holder.b.tvIp.text = "地址 ${d.ip}:${d.tcpPort}"
        val connected = Hub.connState == ConnState.CONNECTED && Hub.peerIp == d.ip
        val connecting = Hub.connState == ConnState.CONNECTING
        with(holder.b.btnAction) {
            when {
                connected -> { text = "已连接"; setOnClickListener { Hub.disconnect() } }
                connecting -> { text = "连接中"; setOnClickListener(null) }
                Hub.connState == ConnState.CONNECTED -> {
                    text = "连接"; setOnClickListener(null)
                    isEnabled = false
                }
                else -> {
                    text = "连接"
                    isEnabled = true
                    setOnClickListener { onClick(d) }
                }
            }
        }
        holder.itemView.setOnClickListener {
            if (connected) Hub.disconnect() else if (Hub.connState != ConnState.CONNECTED) onClick(d)
        }
    }

    override fun getItemCount(): Int = items.size
}
