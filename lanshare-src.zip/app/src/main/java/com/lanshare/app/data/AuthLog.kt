package com.lanshare.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 本地登录日志：记录发送验证码、登录成功/失败等事件。
 * 日志存 SharedPreferences，最多保留最近 200 条。
 */
object AuthLog {
    private const val FILE = "lanshare_auth_log"
    private const val KEY_LOGS = "logs"
    private const val MAX = 200

    private fun sp(ctx: Context) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun record(ctx: Context, action: String, email: String = "", detail: String = "") {
        val now = System.currentTimeMillis()
        val entry = JSONObject().apply {
            put("time", now)
            put("action", action)
            put("email", email)
            put("detail", detail)
        }
        val raw = sp(ctx).getString(KEY_LOGS, "[]") ?: "[]"
        val arr = try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
        arr.put(entry)
        // 只保留最近 MAX 条
        val trimmed = JSONArray()
        val start = maxOf(0, arr.length() - MAX)
        for (i in start until arr.length()) {
            trimmed.put(arr.get(i))
        }
        sp(ctx).edit().putString(KEY_LOGS, trimmed.toString()).apply()
    }

    fun all(ctx: Context): String {
        val raw = sp(ctx).getString(KEY_LOGS, "[]") ?: "[]"
        val arr = try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
        val sb = StringBuilder()
        val fmt = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.getDefault())
        for (i in 0 until arr.length()) {
            try {
                val o = arr.getJSONObject(i)
                val t = fmt.format(java.util.Date(o.getLong("time")))
                val a = o.getString("action")
                val e = o.optString("email", "")
                val d = o.optString("detail", "")
                sb.append(t).append("  ").append(a)
                if (e.isNotEmpty()) sb.append("  ").append(e)
                if (d.isNotEmpty()) sb.append("  [").append(d).append("]")
                sb.append("\n")
            } catch (_: Exception) {
            }
        }
        return if (sb.isEmpty()) "暂无日志" else sb.toString().trimEnd()
    }

    fun clear(ctx: Context) {
        sp(ctx).edit().remove(KEY_LOGS).apply()
    }
}
