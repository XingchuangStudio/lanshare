package com.lanshare.app.net

import org.json.JSONObject

/** 局域网通信协议常量与帧编解码（纯 JVM） */
object Protocol {
    const val DISCOVERY_PORT = 8899
    const val TCP_PORT = 8900
    const val BROADCAST_INTERVAL_MS = 2000L
    const val DEVICE_TIMEOUT_MS = 9000L

    // ---- UDP 发现报文 ----
    fun ping(name: String, tcpPort: Int): String =
        JSONObject().put("t", "ping").put("name", name).put("tcpPort", tcpPort).toString()

    fun pong(name: String, tcpPort: Int): String =
        JSONObject().put("t", "pong").put("name", name).put("tcpPort", tcpPort).toString()

    // ---- TCP 帧 ----
    fun hello(name: String): String =
        JSONObject().put("t", "hello").put("name", name).toString() + "\n"

    fun textFrame(content: String, ts: Long): String =
        JSONObject()
            .put("t", "msg").put("kind", "text")
            .put("content", content).put("ts", ts)
            .toString() + "\n"

    fun fileHeader(name: String, size: Long, ts: Long): String =
        JSONObject()
            .put("t", "msg").put("kind", "file")
            .put("name", name).put("size", size).put("ts", ts)
            .toString() + "\n"

    fun parse(line: String): JSONObject = JSONObject(line)
}
