package com.lanshare.app.ui.devices

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.lanshare.app.data.Prefs
import com.lanshare.app.databinding.FragmentDevicesBinding
import com.lanshare.app.net.ConnState
import com.lanshare.app.net.Hub
import com.lanshare.app.net.PairCode

class DevicesFragment : Fragment(), Hub.UiListener {

    private var _b: FragmentDevicesBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: DeviceAdapter
    private val handler = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentDevicesBinding.inflate(inflater, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = DeviceAdapter { Hub.connect(it) }
        b.rvDevices.layoutManager = LinearLayoutManager(requireContext())
        b.rvDevices.adapter = adapter
        b.btnPairConnect.setOnClickListener { showPairDialog() }
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(this)
        handler.post(refresh)
    }

    override fun onPause() {
        Hub.removeListener(this)
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun render() {
        adapter.submit(Hub.devices.toList())
        b.tvEmpty.visibility = if (Hub.devices.isEmpty()) View.VISIBLE else View.GONE
        b.tvSelf.text = "本机：${Prefs.getNickname(requireContext())}"
        val ip = Hub.localIp()
        b.tvSelfIp.text = if (ip.isNullOrBlank())
            "未检测到局域网地址，请确认已连接 Wi-Fi（不能只用移动数据）"
        else "局域网地址：$ip"
        val code = Hub.pairCode()
        b.tvPairCode.text = PairCode.pretty(code)
        b.tvSearching.text = when (Hub.connState) {
            ConnState.CONNECTED -> "已连接到 ${if (Hub.peerName.isBlank()) "对端设备" else Hub.peerName}"
            ConnState.CONNECTING -> "正在建立连接…"
            ConnState.IDLE -> "正在搜索附近设备（广播 + 全网段扫描）…"
        }
    }

    private fun showPairDialog() {
        if (Hub.connState == ConnState.CONNECTED) {
            Toast.makeText(requireContext(), "已连接设备，请先断开", Toast.LENGTH_SHORT).show()
            return
        }
        val et = EditText(requireContext()).apply {
            hint = "输入对方 6 位配对码，或完整 IP"
            setSingleLine(true)
        }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(requireContext()).apply {
            setPadding(pad, pad, pad, 0)
            addView(et)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("配对码 / IP 直连")
            .setMessage("让对方在「设备」页把其配对码告诉你；也可直接输入对方局域网 IP（如 192.168.1.23）")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("连接") { _, _ ->
                val input = et.text.toString().trim()
                if (input.isEmpty()) {
                    Toast.makeText(requireContext(), "请输入配对码或 IP", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val err = if (input.contains('.')) Hub.connectByIp(input)
                else Hub.connectByCode(input)
                if (err != null) Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show()
                else Toast.makeText(requireContext(), "正在连接，请稍候…", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onDevicesChanged() { render() }
    override fun onConnectionChanged() { render() }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
