package com.lanshare.app.data

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * 纯本地账号体系：注册信息只保存在本机，不上传任何服务器。
 * 密码以 SHA-256 + 随机盐的形式存储，不保存明文。
 */
object Prefs {
    private const val FILE = "lanshare_account"
    private const val KEY_ACCOUNT = "account"
    private const val KEY_SALT = "salt"
    private const val KEY_HASH = "pwd_hash"
    private const val KEY_NICK = "nickname"
    private const val KEY_LOGGED_IN = "logged_in"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isRegistered(ctx: Context): Boolean =
        sp(ctx).getString(KEY_ACCOUNT, null) != null

    fun isLoggedIn(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_LOGGED_IN, false)

    fun getAccount(ctx: Context): String = sp(ctx).getString(KEY_ACCOUNT, "") ?: ""

    fun getNickname(ctx: Context): String {
        val n = sp(ctx).getString(KEY_NICK, "") ?: ""
        return n.ifBlank { "本机用户" }
    }

    fun setNickname(ctx: Context, name: String) {
        sp(ctx).edit().putString(KEY_NICK, name.trim()).apply()
    }

    /** 账号格式校验：手机号（11 位 1 开头）或邮箱 */
    fun validateAccount(account: String): String? {
        val a = account.trim()
        val phone = Regex("^1\\d{10}$")
        val email = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
        return when {
            a.isEmpty() -> "请输入手机号或邮箱"
            !phone.matches(a) && !email.matches(a) -> "账号格式不正确，需为 11 位手机号或邮箱"
            else -> null
        }
    }

    /** 注册：返回 null 表示成功，否则为错误提示。本地仅保留一个账号。 */
    fun register(ctx: Context, account: String, password: String, confirm: String): String? {
        val a = account.trim()
        validateAccount(a)?.let { return it }
        if (password.length < 6) return "密码至少 6 位"
        if (password != confirm) return "两次输入的密码不一致"
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.toHex()
        val hash = hash(password, salt)
        sp(ctx).edit()
            .putString(KEY_ACCOUNT, a)
            .putString(KEY_SALT, salt)
            .putString(KEY_HASH, hash)
            .putString(KEY_NICK, if (a.contains("@")) a.substringBefore("@") else "用户${a.takeLast(4)}")
            .putBoolean(KEY_LOGGED_IN, true)
            .apply()
        return null
    }

    /** 登录校验 */
    fun login(ctx: Context, account: String, password: String): String? {
        val saved = sp(ctx).getString(KEY_ACCOUNT, null)
            ?: return "尚未注册，请先注册账号"
        if (account.trim() != saved) return "账号不存在，请先注册"
        val salt = sp(ctx).getString(KEY_SALT, "") ?: ""
        val expect = sp(ctx).getString(KEY_HASH, "") ?: ""
        if (hash(password, salt) != expect) return "密码错误"
        sp(ctx).edit().putBoolean(KEY_LOGGED_IN, true).apply()
        return null
    }

    /** 邮箱验证码登录：保存登录状态 */
    fun saveLogin(ctx: Context, email: String) {
        val nick = email.substringBefore("@").replaceFirstChar { it.uppercase() }
        sp(ctx).edit()
            .putString(KEY_ACCOUNT, email)
            .putString(KEY_NICK, nick)
            .putBoolean(KEY_LOGGED_IN, true)
            .apply()
    }

    fun logout(ctx: Context) {
        sp(ctx).edit().putBoolean(KEY_LOGGED_IN, false).apply()
    }

    // ===== 待验证的验证码（App 被杀后重开仍可继续） =====
    private const val KEY_PENDING_EMAIL = "pending_code_email"
    private const val KEY_PENDING_CODE = "pending_code_value"
    private const val KEY_PENDING_AT = "pending_code_at"

    fun savePendingCode(ctx: Context, email: String, code: String, at: Long) {
        sp(ctx).edit()
            .putString(KEY_PENDING_EMAIL, email)
            .putString(KEY_PENDING_CODE, code)
            .putLong(KEY_PENDING_AT, at)
            .apply()
    }

    fun getPendingCodeEmail(ctx: Context): String = sp(ctx).getString(KEY_PENDING_EMAIL, "") ?: ""
    fun getPendingCode(ctx: Context): String = sp(ctx).getString(KEY_PENDING_CODE, "") ?: ""
    fun getPendingCodeAt(ctx: Context): Long = sp(ctx).getLong(KEY_PENDING_AT, 0L)

    fun clearPendingCode(ctx: Context) {
        sp(ctx).edit()
            .remove(KEY_PENDING_EMAIL)
            .remove(KEY_PENDING_CODE)
            .remove(KEY_PENDING_AT)
            .apply()
    }

    private fun hash(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(salt.toByteArray(Charsets.UTF_8))
        return md.digest(password.toByteArray(Charsets.UTF_8)).toHex()
    }

    private fun ByteArray.toHex(): String =
        joinToString("") { "%02x".format(it) }

    // ===== 扩展设置：文件路径 / 主题色 / AI / 发信邮箱 =====
    private const val KEY_RECV_DIR = "recv_dir"
    private const val KEY_THEME = "theme_color"
    private const val KEY_AI_URL = "ai_base_url"
    private const val KEY_AI_KEY = "ai_api_key"
    private const val KEY_AI_MODEL = "ai_model"
    private const val KEY_SMTP_USER = "smtp_user"
    private const val KEY_SMTP_PASS = "smtp_pass"
    private const val KEY_SMTP_HOST = "smtp_host"
    private const val KEY_SMTP_PORT = "smtp_port"

    fun getSmtpUser(ctx: Context): String = sp(ctx).getString(KEY_SMTP_USER, "") ?: ""
    fun getSmtpPass(ctx: Context): String = sp(ctx).getString(KEY_SMTP_PASS, "") ?: ""
    fun getSmtpHost(ctx: Context): String = sp(ctx).getString(KEY_SMTP_HOST, "smtp.aliyun.com") ?: "smtp.aliyun.com"
    fun getSmtpPort(ctx: Context): Int = sp(ctx).getInt(KEY_SMTP_PORT, 465)

    fun setSmtp(ctx: Context, user: String, pass: String) {
        sp(ctx).edit()
            .putString(KEY_SMTP_USER, user.trim())
            .putString(KEY_SMTP_PASS, pass.trim())
            .apply()
    }

    fun hasSmtp(ctx: Context): Boolean =
        getSmtpUser(ctx).isNotBlank() && getSmtpPass(ctx).isNotBlank()

    fun getRecvDir(ctx: Context): String {
        val d = sp(ctx).getString(KEY_RECV_DIR, null)
        return if (d.isNullOrBlank()) "LANShare" else d.trim()
    }
    fun setRecvDir(ctx: Context, path: String) = sp(ctx).edit().putString(KEY_RECV_DIR, path).apply()

    fun getThemeColor(ctx: Context): Int = sp(ctx).getInt(KEY_THEME, 0xFF2B579A.toInt())
    fun setThemeColor(ctx: Context, color: Int) = sp(ctx).edit().putInt(KEY_THEME, color).apply()

    fun getAiBaseUrl(ctx: Context): String = sp(ctx).getString(KEY_AI_URL, "https://api.deepseek.com/v1") ?: "https://api.deepseek.com/v1"
    fun setAiBaseUrl(ctx: Context, v: String) = sp(ctx).edit().putString(KEY_AI_URL, v).apply()
    fun getAiKey(ctx: Context): String = sp(ctx).getString(KEY_AI_KEY, "") ?: ""
    fun setAiKey(ctx: Context, v: String) = sp(ctx).edit().putString(KEY_AI_KEY, v).apply()
    fun getAiModel(ctx: Context): String = sp(ctx).getString(KEY_AI_MODEL, "deepseek-chat") ?: "deepseek-chat"
    fun setAiModel(ctx: Context, v: String) = sp(ctx).edit().putString(KEY_AI_MODEL, v).apply()
}
