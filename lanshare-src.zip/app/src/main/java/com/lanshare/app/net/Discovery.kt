package com.lanshare.app.net

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 局域网设备发现（纯 JVM 实现，不依赖 Android 框架，便于在电脑上双实例实测）。
 *
 * 三条发现路径互为兜底：
 *  1) 网卡定向广播：向每个网卡自己的广播地址（如 192.168.1.255）发 ping；
 *  2) 受限广播：向 255.255.255.255 发 ping；
 *  3) 同 /24 网段单播扫描：逐个地址单播 ping —— 当广播被路由器 AP 隔离、
 *     系统或 Wi-Fi 芯片丢弃时，单播通常仍可达，是最可靠的兜底手段。
 */
class Discovery(
    private val selfName: () -> String,
    private val onFound: (name: String, ip: String, port: Int) -> Unit,
    private val acquireMulticastLock: () -> Unit = {},
    private val releaseMulticastLock: () -> Unit = {},
    private val listenPort: Int = Protocol.DISCOVERY_PORT,
    private val peerPort: Int = Protocol.DISCOVERY_PORT,
    private val tcpPort: Int = Protocol.TCP_PORT,
    private val enableSubnetScan: Boolean = true,
    private val overrideLocalIp: String? = null
) {
    private val running = AtomicBoolean(false)
    @Volatile private var socket: DatagramSocket? = null
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "lan-discovery").apply { isDaemon = true }
    }

    /** 本机全部 IPv4 地址，用于过滤自己发出的包回环 */
    fun localIpV4All(): Set<String> {
        if (overrideLocalIp != null) return setOf(overrideLocalIp)
        val set = mutableSetOf<String>()
        try {
            for (iface in NetworkInterface.getNetworkInterfaces()) {
                if (!iface.isUp || iface.isLoopback) continue
                for (addr in iface.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        addr.hostAddress?.let { set.add(it) }
                    }
                }
            }
        } catch (_: Exception) { }
        return set
    }

    private fun isPrivateIpv4(ip: String): Boolean {
        if (ip.startsWith("192.168.") || ip.startsWith("10.")) return true
        if (ip.startsWith("172.")) {
            val seg = ip.split(".")
            val second = seg.getOrNull(1)?.toIntOrNull()
            return seg.size == 4 && second != null && second in 16..31
        }
        return false
    }

    /** 本机在局域网中的 IPv4 地址，优先返回私有网段（WLAN/热点）地址 */
    fun localIpV4(): String? {
        val all = localIpV4All()
        return all.firstOrNull { isPrivateIpv4(it) } ?: all.firstOrNull()
    }

    fun start() {
        if (running.getAndSet(true)) return
        runCatching { acquireMulticastLock() }
        executor.execute { runLoop() }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        runCatching { socket?.close() }
        socket = null
        runCatching { releaseMulticastLock() }
    }

    private fun runLoop() {
        val selfIps = localIpV4All()
        try {
            val s = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(listenPort))
                soTimeout = 800
            }
            socket = s
            val buf = ByteArray(2048)
            var lastBroadcast = 0L
            var lastScan = 0L
            while (running.get()) {
                val packet = DatagramPacket(buf, buf.size)
                var received = false
                try {
                    s.receive(packet)
                    received = true
                } catch (_: java.net.SocketTimeoutException) { }
                if (!running.get()) break
                // 注意：receive 超时后 packet 不会被填充（address 为 null、length 仍是缓冲区长度），
                // 必须用 received 标记判断，否则会空指针并导致整个发现线程退出
                if (received && packet.address != null && packet.length > 0) {
                    val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    handlePacket(text, packet.address.hostAddress ?: "", selfIps)
                }
                val now = System.currentTimeMillis()
                // 广播：每 2 秒
                if (now - lastBroadcast >= Protocol.BROADCAST_INTERVAL_MS) {
                    lastBroadcast = now
                    sendBroadcasts(s)
                }
                // 单播扫描：每 5 秒一轮（广播失效时的关键兜底）
                if (enableSubnetScan && now - lastScan >= 5000) {
                    lastScan = now
                    subnetScan(s)
                }
            }
        } catch (e: Exception) {
            if (running.get()) e.printStackTrace()
        } finally {
            runCatching { socket?.close() }
            socket = null
        }
    }

    private fun handlePacket(text: String, fromIp: String, selfIps: Set<String>) {
        try {
            val json = Protocol.parse(text)
            val type = json.optString("t")
            val name = json.optString("name", "未知设备")
            val fromTcpPort = json.optInt("tcpPort", Protocol.TCP_PORT)
            if (fromIp in selfIps) return // 过滤自己的回环
            when (type) {
                "ping" -> {
                    reply(fromIp, Protocol.pong(selfName(), fromTcpPort))
                    onFound(name, fromIp, fromTcpPort)
                }
                "pong" -> onFound(name, fromIp, fromTcpPort)
            }
        } catch (_: Exception) { }
    }

    /** 向各网卡定向广播地址 + 受限广播地址发送 ping */
    private fun sendBroadcasts(s: DatagramSocket) {
        val data = Protocol.ping(selfName(), tcpPort).toByteArray(Charsets.UTF_8)
        val targets = LinkedHashSet<String>()
        try {
            for (iface in NetworkInterface.getNetworkInterfaces()) {
                if (!iface.isUp || iface.isLoopback) continue
                for (ia in iface.interfaceAddresses) {
                    ia.broadcast?.hostAddress?.let { targets.add(it) }
                }
            }
        } catch (_: Exception) { }
        targets.add("255.255.255.255")
        for (host in targets) sendTo(s, data, host)
    }

    /** 对本机所在 /24 网段逐地址单播 ping */
    private fun subnetScan(s: DatagramSocket) {
        val me = localIpV4() ?: return
        val parts = me.split(".")
        if (parts.size != 4) return
        val prefix = "${parts[0]}.${parts[1]}.${parts[2]}."
        val myLast = parts[3].toIntOrNull() ?: -1
        val data = Protocol.ping(selfName(), tcpPort).toByteArray(Charsets.UTF_8)
        for (d in 1..254) {
            if (!running.get()) break
            if (d == myLast) continue
            sendTo(s, data, prefix + d)
        }
    }

    private fun sendTo(s: DatagramSocket, data: ByteArray, host: String) {
        try {
            s.send(DatagramPacket(data, data.size, InetAddress.getByName(host), peerPort))
        } catch (_: Exception) { }
    }

    private fun reply(ip: String, msg: String) {
        try {
            val data = msg.toByteArray(Charsets.UTF_8)
            socket?.send(DatagramPacket(data, data.size, InetAddress.getByName(ip), peerPort))
        } catch (_: Exception) { }
    }
}
