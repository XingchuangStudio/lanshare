package com.lanshare.app.ui.chat

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.lanshare.app.databinding.FragmentChatBinding
import com.lanshare.app.net.ConnState
import com.lanshare.app.net.Hub

class ChatFragment : Fragment(), Hub.UiListener {

    private var _b: FragmentChatBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: MessageAdapter

    private val pickFile = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) sendSelectedFile(uri)
    }

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentChatBinding.inflate(inflater, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = MessageAdapter()
        b.rvMessages.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        b.rvMessages.adapter = adapter
        b.btnSend.setOnClickListener {
            val text = b.etMessage.text.toString()
            if (text.isBlank()) return@setOnClickListener
            Hub.sendText(text)
            b.etMessage.setText("")
        }
        b.btnFile.setOnClickListener {
            if (Hub.connState != ConnState.CONNECTED) {
                Toast.makeText(requireContext(), "请先连接一台设备", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pickFile.launch("*/*")
        }
    }

    private fun sendSelectedFile(uri: Uri) {
        var name = "文件_${System.currentTimeMillis()}"
        var size = 0L
        runCatching {
            requireContext().contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idxName = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val idxSize = c.getColumnIndex(OpenableColumns.SIZE)
                if (c.moveToFirst()) {
                    if (idxName >= 0) name = c.getString(idxName) ?: name
                    if (idxSize >= 0 && !c.isNull(idxSize)) size = c.getLong(idxSize)
                }
            }
        }
        Hub.sendFile(uri, name, size)
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(this)
        refresh()
    }

    override fun onPause() {
        Hub.removeListener(this)
        super.onPause()
    }

    private fun refresh() {
        adapter.submit(Hub.messages.toList())
        b.rvMessages.post {
            if (Hub.messages.isNotEmpty())
                b.rvMessages.scrollToPosition(Hub.messages.size - 1)
        }
        when (Hub.connState) {
            ConnState.CONNECTED -> {
                val who = if (Hub.peerName.isBlank()) "对端设备" else Hub.peerName
                b.tvConnBar.text = "已连接：$who（${Hub.peerIp ?: "-"}），可双向收发"
            }
            ConnState.CONNECTING -> b.tvConnBar.text = "正在建立连接…"
            ConnState.IDLE -> b.tvConnBar.text = "未连接设备，请到「设备」页搜索并连接"
        }
    }

    override fun onMessagesChanged() { if (_b != null) refresh() }
    override fun onConnectionChanged() { if (_b != null) refresh() }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
