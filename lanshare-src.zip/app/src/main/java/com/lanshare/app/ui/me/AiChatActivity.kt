package com.lanshare.app.ui.me

import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.lanshare.app.data.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiChatActivity : AppCompatActivity() {
    private lateinit var chatCol: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private val history = mutableListOf<Pair<String, String>>()
    private var sending = false

    companion object { private const val TAG = "AiChat" }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF5F5F7.toInt()) }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(12), dp(14))
            setBackgroundColor(0xFF2B579A.toInt())
        }
        val title = TextView(this).apply {
            text = "AI 对话"; setTextColor(0xFFFFFFFF.toInt()); textSize = 17f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsBtn = TextView(this).apply {
            text = "设置"; setTextColor(0xFFFFFFFF.toInt()); textSize = 14f
            setPadding(dp(14), dp(8), dp(4), dp(8))
        }
        settingsBtn.setOnClickListener { showSettings() }
        topBar.addView(title); topBar.addView(settingsBtn)
        root.addView(topBar)

        scroll = ScrollView(this)
        chatCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        scroll.addView(chatCol)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        input = EditText(this).apply {
            hint = "请输入消息"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        sendBtn = Button(this).apply { text = "发送" }
        sendBtn.setOnClickListener { onSend() }
        row.addView(input); row.addView(sendBtn)
        root.addView(row)
        setContentView(root)

        if (Prefs.getAiKey(this).isBlank()) {
            addBubble("system", "尚未配置 API 接入参数。点击右上角「设置」填写 Base URL、API Key 与模型名称。")
        } else {
            addBubble("system", "已接入模型：${Prefs.getAiModel(this)}。")
        }
    }

    private fun showSettings() {
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), 0)
        }
        fun et(hint: String, cur: String) = EditText(this).apply {
            this.hint = hint; setText(cur); setSingleLine(false); minLines = 1
        }
        val etUrl = et("Base URL", Prefs.getAiBaseUrl(this))
        val etKey = et("API Key", Prefs.getAiKey(this))
        val etModel = et("模型名称", Prefs.getAiModel(this))
        lay.addView(etUrl); lay.addView(etKey); lay.addView(etModel)
        AlertDialog.Builder(this)
            .setTitle("API 接入设置")
            .setView(lay)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setAiBaseUrl(this, etUrl.text.toString().trim())
                Prefs.setAiKey(this, etKey.text.toString().trim())
                Prefs.setAiModel(this, etModel.text.toString().trim())
                Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun onSend() {
        if (sending) return
        val q = input.text.toString().trim()
        if (q.isEmpty()) { Toast.makeText(this, "请输入内容", Toast.LENGTH_SHORT).show(); return }
        if (Prefs.getAiKey(this).isBlank() || Prefs.getAiBaseUrl(this).isBlank()) {
            Toast.makeText(this, "请先在 设置 中配置 API 接入参数", Toast.LENGTH_LONG).show()
            showSettings(); return
        }
        history.add("user" to q)
        addBubble("user", q)
        input.setText("")
        val thinking = addBubble("assistant", "正在请求…")
        sending = true
        sendBtn.isEnabled = false
        Thread {
            var errMsg: String? = null
            var ans: String? = null
            try {
                val base = Prefs.getAiBaseUrl(this).trimEnd('/')
                val url = if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
                val key = Prefs.getAiKey(this)
                val model = Prefs.getAiModel(this)
                val msgs = JSONArray()
                for ((role, content) in history) msgs.put(JSONObject().put("role", role).put("content", content))
                val body = JSONObject().apply {
                    put("model", model)
                    put("messages", msgs)
                    put("stream", false)
                }.toString()
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    connectTimeout = 20000
                    readTimeout = 60000
                }
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val raw = if (code in 200..299) {
                    conn.inputStream.bufferedReader().readText()
                } else {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: ""
                    throw RuntimeException("HTTP $code: ${err.take(400)}")
                }
                val obj = JSONObject(raw)
                ans = obj.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            } catch (e: Exception) {
                Log.e(TAG, "ai error", e)
                errMsg = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                chatCol.removeView(thinking)
                if (ans != null) {
                    history.add("assistant" to ans!!)
                    addBubble("assistant", ans!!)
                } else {
                    addBubble("system", "请求失败：$errMsg")
                }
                sending = false
                sendBtn.isEnabled = true
            }
        }.start()
    }

    private fun addBubble(role: String, text: String): View {
        val tv = TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            maxWidth = resources.displayMetrics.widthPixels - dp(48)
            when (role) {
                "user" -> setBackgroundColor(0xFF2B579A.toInt()).also { setTextColor(0xFFFFFFFF.toInt()) }
                "assistant" -> setBackgroundColor(0xFFFFFFFF.toInt()).also { setTextColor(0xFF222222.toInt()) }
                else -> setBackgroundColor(0x00000000).also { setTextColor(0xFF888888.toInt()); textSize = 12f }
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
            marginStart = if (role == "user") dp(48) else 0
            marginEnd = if (role == "user") 0 else dp(48)
            gravity = if (role == "user") Gravity.END else Gravity.START
        }
        chatCol.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
