package com.lanshare.app.net

/**
 * 内置发信账号。验证码邮件统一由这个账号发出，
 * 用户端不需要填写任何配置，输入自己的邮箱即可收到验证码。
 */
object MailConfig {
    /** 发信邮箱 */
    const val USER = "xcgzsyou@aliyun.com"

    /** SMTP 授权码（邮箱设置里开启 SMTP 服务时生成，不是登录密码） */
    const val PASS = "REPLACE_WITH_AUTH_CODE"

    /** SMTP 服务器与端口，阿里云邮箱走 465 隐式 SSL */
    const val HOST = "smtp.aliyun.com"
    const val PORT = 465

    fun isReady(): Boolean = PASS.isNotBlank() && !PASS.startsWith("REPLACE_")
}
