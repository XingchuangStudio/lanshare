package com.lanshare.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.lanshare.app.net.Hub

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        Hub.init(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "局域网传输服务",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "维持设备发现与消息文件收发" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    companion object {
        const val CHANNEL_ID = "lanshare_service"
        lateinit var instance: App
            private set
    }
}
