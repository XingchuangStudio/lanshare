package com.lanshare.app.net

/**
 * 配对码：在自动/广播发现失效时，靠 6 位数字直连。
 *
 * 同一局域网通常前两段相同（如都是 192.168.1.x）。配对码编码本机 IP 的
 * 后两段 c.d：cccddd（各 3 位、不足补零）。对端输入后，用自己 IP 的前两段
 * 拼回完整 IP，直接发起 TCP 连接，完全绕开 UDP 发现。
 */
object PairCode {

    fun encode(ip: String?): String? {
        val p = ip?.split(".") ?: return null
        if (p.size != 4) return null
        val c = p[2].toIntOrNull() ?: return null
        val d = p[3].toIntOrNull() ?: return null
        if (c !in 0..255 || d !in 0..255) return null
        return "%03d%03d".format(c, d)
    }

    /** 便于展示，每 3 位分组，如 "001 023" */
    fun pretty(code: String?): String {
        if (code == null || code.length != 6) return code ?: "------"
        return code.substring(0, 3) + " " + code.substring(3)
    }

    /** 用本机 IP 前两段 + 配对码还原对方 IP；输入非法返回 null */
    fun decode(myIp: String?, rawInput: String): String? {
        if (myIp == null) return null
        val mp = myIp.split(".")
        if (mp.size != 4) return null
        val code = rawInput.filter { it.isDigit() }
        if (code.length != 6) return null
        val c = code.substring(0, 3).toInt()
        val d = code.substring(3, 6).toInt()
        if (c !in 0..255 || d !in 0..255) return null
        return "${mp[0]}.${mp[1]}.$c.$d"
    }

    fun isIpAddress(input: String): Boolean {
        val p = input.trim().split(".")
        if (p.size != 4) return false
        return p.all { (it.toIntOrNull() ?: -1) in 0..255 }
    }
}
