package com.lanshare.app.ui.chat

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.lanshare.app.R
import com.lanshare.app.data.ChatMessage
import com.lanshare.app.databinding.ItemMessageBinding
import com.lanshare.app.net.Hub
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter : RecyclerView.Adapter<MessageAdapter.VH>() {

    private val items = ArrayList<ChatMessage>()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun submit(list: List<ChatMessage>) {
        val old = items.size
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemMessageBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        with(holder.b) {
            tvTime.text = timeFmt.format(Date(m.time))

            val row = root.getChildAt(1) as LinearLayout
            row.gravity = if (m.outgoing) Gravity.END else Gravity.START
            spLeft.layoutParams = (spLeft.layoutParams as LinearLayout.LayoutParams).apply {
                weight = if (m.outgoing) 1f else 0f
                width = if (m.outgoing) 0 else 0
            }
            spRight.layoutParams = (spRight.layoutParams as LinearLayout.LayoutParams).apply {
                weight = if (m.outgoing) 0f else 1f
                width = 0
            }

            bubble.setBackgroundResource(
                if (m.outgoing) R.drawable.bg_bubble_me else R.drawable.bg_bubble_other
            )

            if (m.isFile) {
                tvText.visibility = View.GONE
                fileCard.visibility = View.VISIBLE
                tvFileName.text = m.fileName
                val sizeText = Hub.humanSize(m.fileSize)
                tvFileMeta.text = when {
                    m.failed -> "传输失败"
                    !m.done -> "传输中 ${m.progress}%"
                    m.outgoing -> "已发送 · $sizeText"
                    else -> "已接收 · $sizeText${if (m.localPath.isNotBlank()) "\n保存于 ${m.localPath}" else ""}"
                }
                progress.progress = m.progress
                progress.visibility = if (m.done) View.GONE else View.VISIBLE
                val iconColor = if (m.outgoing) "#FFFFFF" else "#2E6BE6"
                tvFileName.setTextColor(if (m.outgoing) 0xFFFFFFFF.toInt() else root.context.getColor(R.color.text_main))
                tvFileMeta.setTextColor(if (m.outgoing) 0xDDFFFFFF.toInt() else root.context.getColor(R.color.text_sub))
            } else {
                tvText.visibility = View.VISIBLE
                fileCard.visibility = View.GONE
                tvText.text = m.text
                tvText.setTextColor(if (m.outgoing) 0xFFFFFFFF.toInt() else root.context.getColor(R.color.text_main))
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
