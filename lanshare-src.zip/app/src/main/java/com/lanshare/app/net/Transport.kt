package com.lanshare.app.net

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

enum class ConnState { IDLE, CONNECTING, CONNECTED }

interface TransportListener {
    fun onState(state: ConnState, peerIp: String?)
    fun onPeerHello(name: String)
    fun onText(content: String, ts: Long)
    /** 返回接收文件的输出流；返回 null 表示放弃接收 */
    fun openIncomingSink(fileName: String, size: Long): OutputStream?
    fun onReceiveProgress(fileName: String, percent: Int)
    fun onIncomingFileDone(fileName: String, savedPath: String, size: Long)
    fun onSendProgress(percent: Int)
    fun onSendDone(fileName: String)
    fun onError(msg: String)
}

/**
 * 单连接 TCP 传输（纯 JVM）：对称架构，双方都监听端口，
 * 任一方发起连接后全双工收发。帧格式：一行 JSON 头（以 '\n' 结束），
 * 文件帧头后紧跟 size 字节原始二进制。
 */
class Transport(
    private val selfName: () -> String,
    private val listener: TransportListener,
    private val listenPort: Int = Protocol.TCP_PORT
) {
    @Volatile private var server: ServerSocket? = null
    @Volatile private var conn: Connection? = null
    private val connectExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "lan-connect").apply { isDaemon = true }
    }
    private val alive = AtomicBoolean(false)

    @Volatile var state: ConnState = ConnState.IDLE
        private set
    @Volatile var peerIp: String? = null
        private set

    fun start() {
        if (!alive.compareAndSet(false, true)) return
        Thread({ runServer() }, "lan-tcp-server").apply { isDaemon = true }.start()
    }

    fun stop() {
        alive.set(false)
        runCatching { conn?.close() }
        conn = null
        runCatching { server?.close() }
        server = null
        updateState(ConnState.IDLE, null)
    }

    fun isConnected(): Boolean = state == ConnState.CONNECTED

    fun connect(ip: String, port: Int = listenPort) {
        if (state == ConnState.CONNECTED || state == ConnState.CONNECTING) return
        updateState(ConnState.CONNECTING, null)
        connectExecutor.execute {
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.connect(InetSocketAddress(ip, port), 4000)
                attach(s, outgoing = true)
            } catch (e: Exception) {
                updateState(ConnState.IDLE, null)
                listener.onError("连接失败：${e.message ?: "对方无响应，请确认对方已打开应用或尝试配对码/IP直连"}")
            }
        }
    }

    fun disconnect() {
        conn?.close()
        conn = null
        updateState(ConnState.IDLE, null)
    }

    fun sendText(content: String) {
        val c = conn ?: return listener.onError("尚未连接设备")
        c.write(Protocol.textFrame(content, System.currentTimeMillis()).toByteArray(Charsets.UTF_8))
    }

    /** 流式发送文件，调用方提供 InputStream（由本类负责关闭） */
    fun sendFile(input: InputStream, displayName: String, size: Long) {
        val c = conn
        if (c == null) {
            input.close()
            return listener.onError("尚未连接设备")
        }
        c.writeFile(input, displayName, size)
    }

    private fun runServer() {
        try {
            val ss = ServerSocket(listenPort)
            ss.soTimeout = 2000
            server = ss
            while (alive.get()) {
                val s = try {
                    ss.accept()
                } catch (_: java.net.SocketTimeoutException) {
                    continue
                } catch (e: Exception) {
                    if (alive.get()) e.printStackTrace()
                    break
                }
                if (state == ConnState.CONNECTED) {
                    runCatching { s.close() }
                } else {
                    attach(s, outgoing = false)
                }
            }
        } catch (e: Exception) {
            if (alive.get()) listener.onError("监听端口失败：${e.message}")
        }
    }

    @Synchronized
    private fun attach(socket: Socket, outgoing: Boolean) {
        runCatching { conn?.close() }
        val c = Connection(socket)
        conn = c
        peerIp = socket.inetAddress?.hostAddress
        updateState(ConnState.CONNECTED, peerIp)
        c.write(Protocol.hello(selfName()).toByteArray(Charsets.UTF_8))
        c.startRead()
    }

    private fun updateState(s: ConnState, ip: String?) {
        state = s
        if (s != ConnState.CONNECTED && s != ConnState.CONNECTING) peerIp = null
        listener.onState(s, if (s == ConnState.CONNECTED) peerIp else ip)
    }

    private inner class Connection(val socket: Socket) {
        private val writeExecutor = Executors.newSingleThreadExecutor { r ->
            Thread(r, "lan-writer").apply { isDaemon = true }
        }
        private val reading = AtomicBoolean(true)
        private var out: OutputStream = socket.getOutputStream()

        fun startRead() {
            Thread({ readLoop() }, "lan-reader").apply { isDaemon = true }.start()
        }

        fun write(data: ByteArray) {
            writeExecutor.execute {
                try {
                    out.write(data); out.flush()
                } catch (e: Exception) {
                    handleBroken(e)
                }
            }
        }

        fun writeFile(input: InputStream, name: String, size: Long) {
            writeExecutor.execute {
                try {
                    out.write(Protocol.fileHeader(name, size, System.currentTimeMillis()).toByteArray(Charsets.UTF_8))
                    out.flush()
                    val buf = ByteArray(64 * 1024)
                    var sent = 0L
                    input.use { src ->
                        while (true) {
                            val n = src.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            sent += n
                            if (size > 0) listener.onSendProgress((sent * 100 / size).toInt().coerceIn(0, 100))
                        }
                        out.flush()
                    }
                    listener.onSendProgress(100)
                    listener.onSendDone(name)
                } catch (e: Exception) {
                    handleBroken(e)
                }
            }
        }

        private fun readLoop() {
            var peerClosed = false
            try {
                val input = BufferedInputStream(socket.getInputStream(), 64 * 1024)
                while (reading.get() && !socket.isClosed) {
                    val headerLine = readLine(input)
                    if (headerLine == null) { peerClosed = true; break }
                    val json = Protocol.parse(headerLine)
                    when (json.optString("t")) {
                        "hello" -> listener.onPeerHello(json.optString("name", "对端设备"))
                        "msg" -> when (json.optString("kind")) {
                            "text" -> listener.onText(json.optString("content"), json.optLong("ts"))
                            "file" -> {
                                val name = json.optString("name", "文件")
                                val size = json.optLong("size", 0)
                                val sink = listener.openIncomingSink(name, size)
                                if (sink == null) discard(input, size)
                                else pumpFile(input, sink, name, size)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                if (reading.get()) handleBroken(e)
            }
            // 对端正常关闭（读到流末尾）时也要复位本端连接状态
            if (peerClosed && reading.get()) handleBroken(java.io.IOException("对端已断开"))
        }

        private fun pumpFile(input: BufferedInputStream, sink: OutputStream, name: String, size: Long) {
            var received = 0L
            val buf = ByteArray(64 * 1024)
            var savedPath = ""
            try {
                sink.use { os ->
                    while (received < size) {
                        val want = minOf(buf.size.toLong(), size - received).toInt()
                        val n = input.read(buf, 0, want)
                        if (n <= 0) break
                        os.write(buf, 0, n)
                        received += n
                        listener.onReceiveProgress(name, (received * 100 / size).toInt().coerceIn(0, 100))
                    }
                    os.flush()
                    savedPath = (os as? PathAwareSink)?.path().orEmpty()
                }
                if (received == size) {
                    listener.onIncomingFileDone(name, savedPath, size)
                } else {
                    listener.onError("文件接收不完整：$name")
                }
            } catch (e: Exception) {
                listener.onError("接收文件失败：${e.message}")
            }
        }

        private fun discard(input: BufferedInputStream, size: Long) {
            var left = size
            val buf = ByteArray(64 * 1024)
            while (left > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n <= 0) break
                left -= n
            }
        }

        /** 逐字节读到 '\n'，避免吞掉文件二进制内容 */
        private fun readLine(input: InputStream): String? {
            val bos = ByteArrayOutputStream()
            while (true) {
                val b = input.read()
                if (b == -1) return if (bos.size() == 0) null else bos.toString("UTF-8")
                if (b == '\n'.code) return bos.toString("UTF-8")
                bos.write(b)
                if (bos.size() > 64 * 1024) throw IllegalStateException("帧头过长")
            }
        }

        fun close() {
            reading.set(false)
            runCatching { socket.close() }
            writeExecutor.shutdownNow()
        }

        private fun handleBroken(e: Exception) {
            System.err.println("[Transport] connection broken: ${e.message}")
            reading.set(false)
            runCatching { socket.close() }
            if (conn === this@Connection) {
                conn = null
                updateState(ConnState.IDLE, null)
            }
        }
    }
}

/** 带保存路径的接收输出流标记接口 */
interface PathAwareSink {
    fun path(): String
}
