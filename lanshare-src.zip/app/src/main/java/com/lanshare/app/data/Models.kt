package com.lanshare.app.data

/** 附近发现的设备 */
data class LanDevice(
    val name: String,
    val ip: String,
    val tcpPort: Int,
    var lastSeen: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean = other is LanDevice && other.ip == ip
    override fun hashCode(): Int = ip.hashCode()
}

/** 聊天/传输记录 */
data class ChatMessage(
    val id: Long,
    val outgoing: Boolean,          // true=本机发出, false=对方发来
    val isFile: Boolean,
    val text: String = "",          // 文字内容（文字/链接）
    val fileName: String = "",
    val fileSize: Long = 0L,
    var localPath: String = "",     // 接收后保存路径 / 发送的源路径
    val time: Long = System.currentTimeMillis(),
    var progress: Int = 100,        // 传输进度 0-100
    var done: Boolean = true,
    var failed: Boolean = false
)
