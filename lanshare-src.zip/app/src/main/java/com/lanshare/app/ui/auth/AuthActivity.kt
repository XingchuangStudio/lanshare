package com.lanshare.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.lanshare.app.data.AuthLog
import com.lanshare.app.data.Prefs
import com.lanshare.app.databinding.ActivityAuthBinding
import com.lanshare.app.net.MailConfig
import com.lanshare.app.net.MailSender
import com.lanshare.app.service.LanService
import com.lanshare.app.ui.MainActivity
import java.util.concurrent.Executors

/**
 * 邮箱验证码登录页。
 * 验证码由 App 内置的发信账号统一发出，用户只需填写自己的邮箱，
 * 收件邮箱可以是任意域名，无需在 App 里做任何配置。
 */
class AuthActivity : AppCompatActivity() {

    private lateinit var b: ActivityAuthBinding
    private var timer: CountDownTimer? = null
    private var sending = false

    /** 本次验证码绑定的邮箱，换邮箱后旧验证码立即失效 */
    private var codeEmail: String = ""
    private var codeValue: String = ""
    private var codeAt: Long = 0L

    private val codeValidMillis = 5 * 60 * 1000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.logout(this)
        b = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(b.root)

        // 预填上次登录过的邮箱，省得每次重新输入
        val last = Prefs.getAccount(this)
        if (last.contains("@")) b.etEmail.setText(last)

        restoreCode()

        b.btnSendCode.setOnClickListener { onSendClick() }
        b.btnLogin.setOnClickListener { onLoginClick() }
    }

    /** App 被系统回收后重开，未过期的验证码仍然有效 */
    private fun restoreCode() {
        val email = Prefs.getPendingCodeEmail(this)
        val code = Prefs.getPendingCode(this)
        val at = Prefs.getPendingCodeAt(this)
        if (email.isNotEmpty() && code.isNotEmpty() && at > 0) {
            codeEmail = email
            codeValue = code
            codeAt = at
            if (System.currentTimeMillis() - at <= codeValidMillis) {
                b.btnSendCode.text = "重新发送"
            } else {
                clearCode()
            }
        }
    }

    private fun onSendClick() {
        if (sending) return
        val to = b.etEmail.text.toString().trim()
        if (!isEmail(to)) {
            toast("请输入正确的邮箱地址")
            return
        }
        startSend(to)
    }

    private fun startSend(to: String) {
        if (!MailConfig.isReady()) {
            toast("服务未配置，请联系管理员")
            AuthLog.record(this, "发送验证码", to, "内置发信账号未配置")
            return
        }

        val code = (100000..999999).random().toString()

        sending = true
        b.btnSendCode.isEnabled = false
        b.btnSendCode.text = "发送中…"

        Executors.newSingleThreadExecutor().execute {
            var err: String? = null
            try {
                MailSender.send(
                    host = MailConfig.HOST,
                    port = MailConfig.PORT,
                    user = MailConfig.USER,
                    pass = MailConfig.PASS,
                    to = to,
                    subject = "LANShare 登录验证码",
                    html = buildMailHtml(code)
                )
            } catch (e: Exception) {
                err = e.message ?: "发送失败"
            }

            runOnUiThread {
                sending = false
                if (err == null) {
                    codeEmail = to
                    codeValue = code
                    codeAt = System.currentTimeMillis()
                    Prefs.savePendingCode(this, to, code, codeAt)
                    b.btnSendCode.text = "重新发送"
                    b.btnSendCode.isEnabled = true
                    toast("验证码已发送到 $to")
                    AuthLog.record(this, "发送验证码", to, "成功")
                    startCountdown()
                } else {
                    clearCode()
                    b.btnSendCode.text = "发送验证码"
                    b.btnSendCode.isEnabled = true
                    toast(err)
                    AuthLog.record(this, "发送验证码", to, "失败：$err")
                }
            }
        }
    }

    private fun buildMailHtml(code: String): String {
        return "<div style=\"font-family:-apple-system,Segoe UI,sans-serif;padding:24px\">" +
            "<p style=\"font-size:15px;color:#333\">你的登录验证码是</p>" +
            "<p style=\"font-size:30px;font-weight:bold;letter-spacing:6px;color:#2b579a;margin:16px 0\">$code</p>" +
            "<p style=\"font-size:13px;color:#888\">5 分钟内有效，仅可用于当前邮箱登录。如果不是你本人操作请忽略。</p>" +
            "</div>"
    }

    private fun onLoginClick() {
        val email = b.etEmail.text.toString().trim()
        val input = b.etCode.text.toString().trim()

        if (!isEmail(email)) {
            toast("请输入正确的邮箱地址")
            return
        }
        if (input.length != 6) {
            toast("请输入 6 位验证码")
            AuthLog.record(this, "登录失败", email, "验证码位数不对")
            return
        }
        if (codeValue.isEmpty()) {
            toast("请先获取验证码")
            AuthLog.record(this, "登录失败", email, "未获取验证码")
            return
        }
        // 验证码只对当初收件的那个邮箱有效
        if (email != codeEmail) {
            toast("该验证码不属于这个邮箱，请重新获取")
            AuthLog.record(this, "登录失败", email, "验证码与邮箱不匹配（发放给 $codeEmail）")
            return
        }
        if (System.currentTimeMillis() - codeAt > codeValidMillis) {
            clearCode()
            toast("验证码已过期，请重新获取")
            AuthLog.record(this, "登录失败", email, "验证码过期")
            return
        }
        if (input != codeValue) {
            toast("验证码不正确")
            AuthLog.record(this, "登录失败", email, "验证码错误")
            return
        }

        Prefs.saveLogin(this, email)
        clearCode()
        AuthLog.record(this, "登录成功", email, "")
        runCatching { startService(Intent(this, LanService::class.java)) }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun clearCode() {
        codeEmail = ""
        codeValue = ""
        codeAt = 0L
        Prefs.clearPendingCode(this)
    }

    private fun startCountdown() {
        timer?.cancel()
        timer = object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                b.btnSendCode.isEnabled = false
                b.btnSendCode.text = "${millisUntilFinished / 1000} 秒后重发"
            }

            override fun onFinish() {
                b.btnSendCode.isEnabled = true
                b.btnSendCode.text = "重新发送"
            }
        }.start()
    }

    private fun isEmail(s: String): Boolean =
        Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$").matches(s.trim())

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        timer?.cancel()
    }
}
