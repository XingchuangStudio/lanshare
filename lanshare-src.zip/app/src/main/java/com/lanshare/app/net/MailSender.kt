package com.lanshare.app.net

import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * 轻量 SMTP 客户端，用于直接向邮件服务器投递验证码邮件。
 * 只实现登录后投递一封 HTML 邮件的流程，支持 465 隐式 SSL。
 */
object MailSender {

    class MailException(message: String) : Exception(message)

    fun send(
        host: String,
        port: Int,
        user: String,
        pass: String,
        to: String,
        subject: String,
        html: String
    ) {
        var socket: SSLSocket? = null
        try {
            socket = SSLSocketFactory.getDefault()
                .createSocket(host, port) as SSLSocket
            socket.soTimeout = 20000
            socket.startHandshake()

            val out: OutputStream = socket.outputStream
            val reader = BufferedReader(InputStreamReader(socket.inputStream, "UTF-8"))

            fun readReply(): String {
                var line = reader.readLine() ?: throw MailException("服务器无响应")
                while (line.length > 3 && line[3] == '-') {
                    line = reader.readLine() ?: throw MailException("服务器无响应")
                }
                return line
            }

            fun expect(prefix: String) {
                val line = readReply()
                if (!line.startsWith(prefix)) {
                    throw MailException(friendly(line))
                }
            }

            fun cmd(text: String, prefix: String) {
                out.write((text + "\r\n").toByteArray(Charsets.UTF_8))
                out.flush()
                expect(prefix)
            }

            expect("220")
            cmd("EHLO lanshare", "250")
            cmd("AUTH LOGIN", "334")
            cmd(b64(user), "334")
            cmd(b64(pass), "235")
            cmd("MAIL FROM:<$user>", "250")
            cmd("RCPT TO:<$to>", "250")
            cmd("DATA", "354")

            val encodedSubject = "=?UTF-8?B?" + b64(subject) + "?="
            val bodyB64 = wrap76(b64(html))

            val mail = StringBuilder()
            mail.append("From: \"LANShare\" <").append(user).append(">\r\n")
            mail.append("To: <").append(to).append(">\r\n")
            mail.append("Subject: ").append(encodedSubject).append("\r\n")
            mail.append("MIME-Version: 1.0\r\n")
            mail.append("Content-Type: text/html; charset=UTF-8\r\n")
            mail.append("Content-Transfer-Encoding: base64\r\n")
            mail.append("\r\n")
            mail.append(bodyB64)
            mail.append("\r\n.\r\n")

            out.write(mail.toString().toByteArray(Charsets.UTF_8))
            out.flush()
            expect("250")

            try {
                cmd("QUIT", "221")
            } catch (_: Exception) {
            }
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun b64(s: String): String =
        Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

    private fun wrap76(s: String): String {
        if (s.length <= 76) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val end = minOf(i + 76, s.length)
            sb.append(s, i, end)
            sb.append("\r\n")
            i = end
        }
        return sb.toString()
    }

    /** 把服务器返回的英文错误码翻译成用户看得懂的话 */
    private fun friendly(line: String): String {
        val upper = line.uppercase()
        return when {
            upper.contains("535") || upper.contains("AUTHENTICATION FAILED") ||
                upper.contains("LOGIN FAILED") || upper.contains("AUTH") ->
                "邮箱登录失败，请检查发信邮箱和授权码"
            upper.contains("550") || upper.contains("553") ->
                "收件地址被服务器拒绝，请检查邮箱是否正确"
            upper.contains("421") || upper.contains("TIMEOUT") ->
                "邮件服务器繁忙，请稍后再试"
            upper.contains("554") ->
                "邮件被判定为垃圾邮件，换个内容再试"
            else -> "发送失败：$line"
        }
    }
}
