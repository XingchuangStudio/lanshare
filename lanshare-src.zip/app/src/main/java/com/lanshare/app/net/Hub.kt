package com.lanshare.app.net

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.lanshare.app.data.ChatMessage
import com.lanshare.app.data.LanDevice
import com.lanshare.app.data.Prefs
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.DecimalFormat
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** 全局通信中枢：设备发现 + 连接 + 收发，界面只与 Hub 交互 */
object Hub : TransportListener {

    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool { r ->
        Thread(r, "hub-io").apply { isDaemon = true }
    }

    private lateinit var discovery: Discovery
    private lateinit var transport: Transport

    val devices = CopyOnWriteArrayList<LanDevice>()
    val messages = CopyOnWriteArrayList<ChatMessage>()

    @Volatile var connState = ConnState.IDLE; private set
    @Volatile var peerName: String = ""; private set
    @Volatile var peerIp: String? = null; private set

    private var msgSeq = 0L
    private var started = false

    interface UiListener {
        fun onDevicesChanged() {}
        fun onMessagesChanged() {}
        fun onConnectionChanged() {}
        fun onToast(text: String) {}
    }

    private val listeners = CopyOnWriteArrayList<UiListener>()
    fun addListener(l: UiListener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: UiListener) { listeners.remove(l) }

    private var multicastLock: android.net.wifi.WifiManager.MulticastLock? = null

    fun init(ctx: Context) {
        app = ctx.applicationContext
        discovery = Discovery(
            selfName = { Prefs.getNickname(app) },
            onFound = ::onDeviceFound,
            acquireMulticastLock = {
                runCatching {
                    val wifi = app.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                    multicastLock = wifi.createMulticastLock("lanshare-mcast").apply {
                        setReferenceCounted(false)
                        acquire()
                    }
                }
            },
            releaseMulticastLock = {
                runCatching { multicastLock?.release() }
                multicastLock = null
            }
        )
        transport = Transport({ Prefs.getNickname(app) }, this)
    }

    fun start() {
        if (started) return
        started = true
        discovery.start()
        transport.start()
        main.postDelayed(sweeper, 1000)
    }

    fun stop() {
        if (!started) return
        started = false
        main.removeCallbacks(sweeper)
        discovery.stop()
        transport.stop()
    }

    fun localIp(): String? = discovery.localIpV4()

    // ---------------- 设备发现 ----------------
    private fun onDeviceFound(name: String, ip: String, port: Int) {
        val existing = devices.firstOrNull { it.ip == ip }
        if (existing == null) {
            devices.add(LanDevice(name, ip, port))
        } else {
            existing.lastSeen = System.currentTimeMillis()
            if (existing.name != name) {
                devices.remove(existing)
                devices.add(LanDevice(name, ip, port))
            }
        }
        emitDevices()
    }

    private val sweeper = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val stale = devices.filter { now - it.lastSeen > Protocol.DEVICE_TIMEOUT_MS }
            if (stale.isNotEmpty()) {
                devices.removeAll(stale.toSet())
                emitDevices()
            }
            main.postDelayed(this, 2000)
        }
    }

    fun connect(d: LanDevice) = transport.connect(d.ip, d.tcpPort)
    fun disconnect() = transport.disconnect()

    /** 本机配对码（6 位），无法获取局域网 IP 时返回 null */
    fun pairCode(): String? = PairCode.encode(localIp())

    /** 通过对方 6 位配对码直连；返回 null 表示发起成功，否则为错误提示 */
    fun connectByCode(rawCode: String): String? {
        if (connState == ConnState.CONNECTED) return "已连接设备，请先断开"
        val myIp = localIp() ?: return "本机未连接局域网，请先连接 Wi-Fi"
        val target = PairCode.decode(myIp, rawCode)
            ?: return "配对码应为 6 位数字"
        if (target == myIp) return "配对码是本机自己的，请输入对方设备上的配对码"
        transport.connect(target, Protocol.TCP_PORT)
        return null
    }

    /** 通过对方完整 IP 直连 */
    fun connectByIp(rawIp: String): String? {
        if (connState == ConnState.CONNECTED) return "已连接设备，请先断开"
        val ip = rawIp.trim()
        if (!PairCode.isIpAddress(ip)) return "IP 地址格式不正确"
        if (ip == localIp()) return "这是本机自己的地址，请输入对方的 IP"
        transport.connect(ip, Protocol.TCP_PORT)
        return null
    }

    // ---------------- 发送 ----------------
    fun sendText(content: String) {
        val text = content.trim()
        if (text.isEmpty()) return
        if (connState != ConnState.CONNECTED) { toast("请先在「设备」页连接一台设备"); return }
        transport.sendText(text)
        messages.add(ChatMessage(++msgSeq, true, false, text = text))
        emitMessages()
    }

    fun sendFile(uri: Uri, displayName: String, size: Long) {
        if (connState != ConnState.CONNECTED) { toast("请先在「设备」页连接一台设备"); return }
        val msg = ChatMessage(++msgSeq, true, true, fileName = displayName,
            fileSize = size, progress = 0, done = false)
        messages.add(msg)
        emitMessages()
        io.execute {
            try {
                val input = app.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("无法读取所选文件")
                transport.sendFile(input, displayName, size)
            } catch (e: Exception) {
                msg.failed = true; msg.done = true
                emitMessages(); toast("发送失败：${e.message}")
            }
        }
    }

    // ---------------- TransportListener ----------------
    override fun onState(state: ConnState, peerIp: String?) {
        connState = state
        this.peerIp = peerIp
        if (state == ConnState.CONNECTED) {
            peerName = ""
            messages.clear()
        }
        main.post {
            listeners.forEach { it.onConnectionChanged() }
            listeners.forEach { it.onMessagesChanged() }
        }
    }

    override fun onPeerHello(name: String) {
        peerName = name
        main.post { listeners.forEach { it.onConnectionChanged() } }
    }

    override fun onText(content: String, ts: Long) {
        messages.add(ChatMessage(++msgSeq, false, false, text = content, time = ts))
        emitMessages()
    }

    override fun openIncomingSink(fileName: String, size: Long): OutputStream? {
        val safeName = sanitizeName(fileName)
        val msg = ChatMessage(++msgSeq, false, true, fileName = safeName,
            fileSize = size, progress = 0, done = false)
        messages.add(msg)
        emitMessages()
        return try {
            createDownloadSink(safeName, msg)
        } catch (e: Exception) {
            msg.failed = true; msg.done = true
            emitMessages()
            null
        }
    }

    override fun onReceiveProgress(fileName: String, percent: Int) {
        val m = messages.lastOrNull { !it.outgoing && it.isFile && !it.done } ?: return
        m.progress = percent
        emitMessages()
    }

    override fun onIncomingFileDone(fileName: String, savedPath: String, size: Long) {
        val m = messages.lastOrNull { !it.outgoing && it.isFile && !it.done }
        m?.let {
            it.progress = 100; it.done = true; it.localPath = savedPath
            emitMessages()
            toast("已接收文件：$fileName")
        }
    }

    override fun onSendProgress(percent: Int) {
        val m = messages.lastOrNull { it.outgoing && it.isFile && !it.done } ?: return
        m.progress = percent
        emitMessages()
    }

    override fun onSendDone(fileName: String) {
        val m = messages.lastOrNull { it.outgoing && it.isFile && !it.done }
        m?.let { it.progress = 100; it.done = true }
        emitMessages()
        toast("文件已发送：$fileName")
    }

    override fun onError(msg: String) = toast(msg)

    // ---------------- 文件保存 ----------------
    private fun createDownloadSink(name: String, msg: ChatMessage): OutputStream {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/${com.lanshare.app.data.Prefs.getRecvDir(app)}")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = app.contentResolver.insert(collection, values)
                ?: throw IllegalStateException("无法创建下载文件")
            val raw = app.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("无法写入下载文件")
            object : FileOutputStreamWrap(raw), PathAwareSink {
                override fun close() {
                    super.close()
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    app.contentResolver.update(uri, values, null, null)
                }
                override fun path(): String = "Download/LANShare/$name"
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                com.lanshare.app.data.Prefs.getRecvDir(app)
            )
            if (!dir.exists()) dir.mkdirs()
            var target = File(dir, name)
            var i = 1
            val stem = name.substringBeforeLast('.', name)
            val ext = if (name.contains('.')) name.substringAfterLast('.', "") else ""
            while (target.exists()) {
                target = File(dir, if (ext.isBlank()) "$stem($i)" else "$stem($i).$ext")
                i++
            }
            val fos = FileOutputStream(target)
            object : FileOutputStreamWrap(fos), PathAwareSink {
                override fun path(): String = target.absolutePath
            }
        }
    }

    /** 转发包装，避免直接继承 FileOutputStream 时两种来源构造不一致 */
    private open class FileOutputStreamWrap(private val os: OutputStream) : OutputStream() {
        override fun write(b: Int) = os.write(b)
        override fun write(b: ByteArray, off: Int, len: Int) = os.write(b, off, len)
        override fun flush() = os.flush()
        override fun close() = os.close()
    }

    private fun sanitizeName(raw: String): String {
        var n = raw.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        if (n.isEmpty()) n = "文件_${System.currentTimeMillis()}"
        return n
    }

    fun humanSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble(); var idx = 0
        while (v >= 1024 && idx < units.lastIndex) { v /= 1024; idx++ }
        return "${DecimalFormat("#.##").format(v)} ${units[idx]}"
    }

    // ---------------- 事件派发 ----------------
    private fun emitDevices() = main.post { listeners.forEach { it.onDevicesChanged() } }
    private fun emitMessages() = main.post { listeners.forEach { it.onMessagesChanged() } }
    private fun toast(t: String) { main.post { listeners.forEach { it.onToast(t) } } }
}
