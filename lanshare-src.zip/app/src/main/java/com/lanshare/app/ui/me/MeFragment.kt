package com.lanshare.app.ui.me

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.lanshare.app.R
import com.lanshare.app.data.Prefs
import com.lanshare.app.databinding.FragmentMeBinding
import com.lanshare.app.service.LanService
import com.lanshare.app.ui.auth.AuthActivity

class MeFragment : Fragment() {

    private var _b: FragmentMeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentMeBinding.inflate(inflater, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        b.btnEditNick.setOnClickListener { showEditNickDialog() }
        b.menuAbout.setOnClickListener { open(LegalTexts.TYPE_ABOUT) }
        b.menuPrivacy.setOnClickListener { open(LegalTexts.TYPE_PRIVACY) }
        b.menuAgreement.setOnClickListener { open(LegalTexts.TYPE_AGREEMENT) }
        b.menuCopyright.setOnClickListener { open(LegalTexts.TYPE_COPYRIGHT) }
        b.menuAcknowledgements.setOnClickListener { showAcknowledgements() }
        b.menuRecvDir.setOnClickListener { showRecvDirDialog() }
        b.menuTheme.setOnClickListener { showThemeDialog() }
        b.menuAi.setOnClickListener { showAiDialog() }
        b.btnLogout.setOnClickListener { confirmLogout() }
    }

    override fun onResume() {
        super.onResume()
        b.tvNick.text = Prefs.getNickname(requireContext())
        b.tvAccount.text = "账号：${Prefs.getAccount(requireContext())}"
    }

    private fun showEditNickDialog() {
        val et = EditText(requireContext()).apply {
            setText(Prefs.getNickname(requireContext()))
            setSelection(text.length)
            hint = "输入新的昵称（其他设备将按此名称发现你）"
            setSingleLine(true)
        }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val container = android.widget.FrameLayout(requireContext()).apply {
            setPadding(pad, pad, pad, 0)
            addView(et)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("修改昵称")
            .setView(container)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(requireContext(), "昵称不能为空", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (name.length > 20) {
                    Toast.makeText(requireContext(), "昵称最多 20 个字符", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                Prefs.setNickname(requireContext(), name)
                b.tvNick.text = name
                Toast.makeText(requireContext(), "昵称已更新", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun open(type: String) {
        startActivity(Intent(requireContext(), AboutActivity::class.java).apply {
            putExtra(AboutActivity.EXTRA_TYPE, type)
        })
    }

    private fun showRecvDirDialog() {
        val et = EditText(requireContext()).apply {
            setText(Prefs.getRecvDir(requireContext()))
            hint = "下载目录（Download 下的子目录）"
            setSingleLine(true)
        }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val container = android.widget.FrameLayout(requireContext()).apply {
            setPadding(pad, pad, pad, 0); addView(et)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("文件保存位置")
            .setView(container)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setRecvDir(requireContext(), et.text.toString().trim())
                Toast.makeText(requireContext(), "保存路径已更新", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showThemeDialog() {
        val colors = intArrayOf(0xFF2B579A.toInt(), 0xFF107C10.toInt(), 0xFFC71E1E.toInt(),
            0xFF8B5A2B.toInt(), 0xFF6B2D8E.toInt(), 0xFF007A8A.toInt())
        val names = arrayOf("深蓝", "翠绿", "朱红", "棕褐", "紫", "青")
        AlertDialog.Builder(requireContext())
            .setTitle("选择主题颜色")
            .setItems(names) { _, which ->
                Prefs.setThemeColor(requireContext(), colors[which])
                Toast.makeText(requireContext(), "已切换，重启后生效", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showAiDialog() {
        val lay = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, 0)
            addView(EditText(context).apply {
                setHint("Base URL（https://api.deepseek.com/v1）")
                setText(Prefs.getAiBaseUrl(context))
                setSingleLine(true)
                id = 1
            })
            addView(EditText(context).apply {
                setHint("API Key")
                setText(Prefs.getAiKey(context))
                setSingleLine(true)
                id = 2
            })
            addView(EditText(context).apply {
                setHint("模型名（deepseek-chat / doubao-pro-4k / gpt-4o-mini）")
                setText(Prefs.getAiModel(context))
                setSingleLine(true)
                id = 3
            })
        }
        AlertDialog.Builder(requireContext())
            .setTitle("API 接入设置")
            .setView(lay)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                Prefs.setAiBaseUrl(requireContext(), (lay.findViewById<EditText>(1)).text.toString().trim())
                Prefs.setAiKey(requireContext(), (lay.findViewById<EditText>(2)).text.toString().trim())
                Prefs.setAiModel(requireContext(), (lay.findViewById<EditText>(3)).text.toString().trim())
                Toast.makeText(requireContext(), "已保存", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showAcknowledgements() {
        val projects = arrayOf(
            "AndroidX（Google）",
            "Material Components for Android（Google）",
            "Kotlin / Kotlinx Coroutines（JetBrains）",
            "SwiftUI / Foundation（Apple）",
            "Avalonia UI（Avalonia）",
            ".NET（Microsoft）"
        )
        val urls = arrayOf(
            "https://developer.android.com/jetpack/androidx",
            "https://github.com/material-components/material-components-android",
            "https://kotlinlang.org",
            "https://developer.apple.com/xcode/swiftui/",
            "https://avaloniaui.net",
            "https://dotnet.microsoft.com"
        )
        AlertDialog.Builder(requireContext())
            .setTitle("开源致谢")
            .setItems(projects) { _, which ->
                val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(urls[which]))
                startActivity(intent)
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun confirmLogout() {
        AlertDialog.Builder(requireContext())
            .setTitle("退出登录")
            .setMessage("退出后将停止局域网发现与收发，确定退出吗？")
            .setNegativeButton("取消", null)
            .setPositiveButton("退出") { _, _ ->
                Prefs.logout(requireContext())
                requireContext().stopService(Intent(requireContext(), LanService::class.java))
                val intent = Intent(requireContext(), AuthActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }
}
