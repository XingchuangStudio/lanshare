package com.lanshare.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.lanshare.app.R
import com.lanshare.app.databinding.ActivityMainBinding
import com.lanshare.app.net.ConnState
import com.lanshare.app.net.Hub
import com.lanshare.app.service.LanService
import com.lanshare.app.ui.chat.ChatFragment
import com.lanshare.app.ui.devices.DevicesFragment
import com.lanshare.app.ui.me.MeFragment

class MainActivity : AppCompatActivity(), Hub.UiListener {

    private lateinit var b: ActivityMainBinding
    private val devicesFragment = DevicesFragment()
    private val chatFragment = ChatFragment()
    private val meFragment = MeFragment()
    private var current: Fragment = devicesFragment

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* 权限结果不阻塞使用，缺失时相关功能再提示 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        if (!PrefsLoggedIn()) {
            startActivity(Intent(this, com.lanshare.app.ui.auth.AuthActivity::class.java))
            finish(); return
        }
        startService(Intent(this, LanService::class.java))
        requestNeededPermissions()

        val tx = supportFragmentManager.beginTransaction()
        tx.add(R.id.container, meFragment, "me").hide(meFragment)
        tx.add(R.id.container, chatFragment, "chat").hide(chatFragment)
        tx.add(R.id.container, devicesFragment, "devices")
        tx.commit()

        b.tabDevices.isSelected = true
        b.tabDevices.setOnClickListener { switch(devicesFragment, it) }
        b.tabChat.setOnClickListener { switch(chatFragment, it) }
        b.tabAi.setOnClickListener {
            startActivity(android.content.Intent(this, com.lanshare.app.ui.me.AiChatActivity::class.java))
        }
        b.tabMe.setOnClickListener { switch(meFragment, it) }
    }

    private fun PrefsLoggedIn() = com.lanshare.app.data.Prefs.isLoggedIn(this)

    private fun switch(target: Fragment, tab: View) {
        if (target === current) return
        supportFragmentManager.beginTransaction()
            .hide(current).show(target).commit()
        current = target
        b.tabDevices.isSelected = target === devicesFragment
        b.tabChat.isSelected = target === chatFragment
        b.tabMe.isSelected = target === meFragment
    }

    private fun requestNeededPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            need += Manifest.permission.NEARBY_WIFI_DEVICES
            need += Manifest.permission.POST_NOTIFICATIONS
        } else {
            need += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            need += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        val missing = need.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(this)
    }

    override fun onPause() {
        Hub.removeListener(this)
        super.onPause()
    }

    override fun onToast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
