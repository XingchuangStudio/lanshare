package com.lanshare.app.ui.me

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.lanshare.app.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    private lateinit var b: ActivityAboutBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(b.root)

        val type = intent.getStringExtra(EXTRA_TYPE) ?: LegalTexts.TYPE_ABOUT
        b.tvTitle.text = LegalTexts.titleOf(type)
        b.tvBody.text = LegalTexts.bodyOf(type)
        b.btnBack.setOnClickListener { finish() }
    }

    companion object {
        const val EXTRA_TYPE = "doc_type"
    }
}
