# Keep model / reflection-free; minify disabled by default. Rules below are safety net.
-keep class com.lanshare.app.** { *; }
